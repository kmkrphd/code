# FEML-ADNN Framework

This repository contains the implementation of the **Feature-Enhanced Machine Learning for Attack Detection and Node Neutralization (FEML-ADNN)** model developed for secure and intelligent Wireless Sensor Networks (WSNs).

## 📁 Files Included

- `feml_adnn_pipeline.py` : Main pipeline script implementing feature enhancement, transformer embedding, active learning, and node revocation logic.
- `requirements.txt` : List of Python dependencies.
- `README.md` : Project documentation.

## 🧠 Key Features

- Spectral-based Feature Enhancement (HSNS simulation)
- Transformer-like Embedding
- Active Learning using Uncertainty Sampling
- Decentralized Node Revocation Simulation
- Evaluated using the SensorNetGuard dataset

## ▶️ How to Run

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Place the SensorNetGuard dataset CSV in the same directory.

3. Run the pipeline:
```bash
python feml_adnn_pipeline.py
```

## 📌 Note

For academic use only. Please cite the corresponding manuscript if used.
