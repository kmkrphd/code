"""
FEML-ADNN Pipeline: Feature-Enhanced Machine Learning for Attack Detection and Node Neutralization
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score

# 1. Load Dataset
def load_data(file_path):
    df = pd.read_csv(file_path)
    X = df.drop(columns=["Is_Malicious", "Node_ID", "Timestamp", "IP_Address"], errors='ignore')
    y = df["Is_Malicious"]
    return X, y

# 2. Feature Enhancement
def feature_enhancement(X):
    enhanced = X.copy()
    for col in X.columns:
        enhanced[f"{col}_spec1"] = X[col] * np.random.uniform(0.9, 1.1)
        enhanced[f"{col}_spec2"] = X[col] * np.random.uniform(0.8, 1.2)
    return enhanced

# 3. Transformer Embedding Simulation
def transformer_embedding(X):
    embedded = X.copy()
    for col in embedded.columns:
        embedded[col] = np.tanh(embedded[col])
    return embedded

# 4. Active Learning Loop
def active_learning(X_labeled, y_labeled, X_unlabeled, y_true, iterations=3, N=100):
    model = GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, max_depth=3)
    for i in range(iterations):
        model.fit(X_labeled, y_labeled)
        probs = model.predict_proba(X_unlabeled)[:, 1]
        uncertainty = np.abs(0.5 - probs)
        idx = np.argsort(uncertainty)[:N]
        X_add = X_unlabeled.iloc[idx]
        y_add = y_true.loc[X_add.index]
        X_labeled = pd.concat([X_labeled, X_add])
        y_labeled = pd.concat([y_labeled, y_add])
        X_unlabeled = X_unlabeled.drop(index=X_add.index)
    return model

# 5. Revocation Decision
def revoke_nodes(model, X, threshold=0.6):
    probs = model.predict_proba(X)[:, 1]
    return (probs >= threshold).astype(int)

# 6. Execution Pipeline
def execute_pipeline(file_path):
    X, y = load_data(file_path)
    X = feature_enhancement(X)
    X = transformer_embedding(X)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
    X_labeled = X_train.sample(frac=0.2, random_state=1)
    X_unlabeled = X_train.drop(X_labeled.index)
    model = active_learning(X_labeled, y_train.loc[X_labeled.index], X_unlabeled, y_train)
    predictions = revoke_nodes(model, X_test)
    print("Accuracy:", accuracy_score(y_test, predictions))
    print("Report:\n", classification_report(y_test, predictions))

# Example call:
# execute_pipeline("SensorNetGuard A Dataset for Identifying Malicious Sensor Nodes.csv")
